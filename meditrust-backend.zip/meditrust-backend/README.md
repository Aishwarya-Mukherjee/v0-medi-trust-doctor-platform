# MediTrust — Backend Package Bundle

This bundle contains everything needed to set up and run the MediTrust backend.

---

## 📦 Files Included

| File | Purpose |
|------|---------|
| `package.json` | All Node.js / Next.js dependencies |
| `requirements.txt` | Python utility dependencies |
| `migrations.sql` | All Supabase database migrations |
| `seed.sql` | Sample/test data for development |
| `.env.example` | Environment variable template |
| `install.sh` | One-command setup script |

---

## 🚀 Quick Start

### 1. Copy files to your project root

Place all files from this bundle into your MediTrust project root directory.

### 2. Run the install script

```bash
chmod +x install.sh
./install.sh
```

Or manually:

```bash
# Install Node packages
pnpm install        # or: npm install

# Install Python utilities (optional)
pip3 install -r requirements.txt
```

### 3. Set up environment variables

```bash
cp .env.example .env.local
# Edit .env.local with your actual credentials
```

### 4. Run database migrations

1. Go to your [Supabase Dashboard](https://supabase.com/dashboard)
2. Open **SQL Editor**
3. Paste and run `migrations.sql`
4. Optionally run `seed.sql` for sample doctor data

### 5. Start the development server

```bash
pnpm dev
```

---

## 🔑 Required Credentials

### Supabase (Required)
- Create a project at [supabase.com](https://supabase.com)
- Get `SUPABASE_URL` and `SUPABASE_ANON_KEY` from Project Settings → API

### Anthropic (Required for AI consultation)
- Get `ANTHROPIC_API_KEY` from [console.anthropic.com](https://console.anthropic.com)

### Razorpay (Required for payments)
- Get keys from [dashboard.razorpay.com](https://dashboard.razorpay.com)
- Use test keys for development (`rzp_test_...`)

---

## 🗄️ Database Schema Overview

```
auth.users          ← Supabase managed auth
    │
    ├── profiles        ← Patient & Doctor profiles
    ├── consultations   ← AI / Text / Video sessions
    │       └── messages        ← Real-time chat messages
    ├── medical_records ← Uploaded health documents
    ├── appointments    ← Scheduled doctor visits
    ├── payments        ← Razorpay payment records
    ├── ratings         ← Doctor reviews
    └── doctor_availability ← Doctor schedule slots
```

---

## 📡 Key API Routes

| Route | Method | Description |
|-------|--------|-------------|
| `/api/ai-consultation` | POST | Stream AI medical assistant responses |
| `/api/consultation/text` | POST | Send message in doctor consultation |
| `/api/medical-records/upload` | POST | Upload medical documents |
| `/api/payments/create-order` | POST | Create Razorpay payment order |
| `/api/payments/verify` | POST | Verify payment completion |

---

## 🛡️ Security Notes

- All tables use **Row Level Security (RLS)** — users can only access their own data
- Doctors can only see patient data during active consultations
- Medical records are private by default (`is_shared = FALSE`)
- Storage buckets enforce path-based access (`userId/filename`)
- Never expose `SUPABASE_SERVICE_ROLE_KEY` to the client

---

## 🔄 Real-time Features

Messages use Supabase Realtime. The `messages` table is added to the `supabase_realtime` publication in `migrations.sql`. No extra configuration needed.

---

## 🧪 Development Tips

- Use Razorpay **test mode keys** (`rzp_test_...`) — no real money charged
- The AI consultation uses `claude-sonnet-4-20250514` model
- Run `pnpm build` before deploying to catch TypeScript errors
