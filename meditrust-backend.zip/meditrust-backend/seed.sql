-- ============================================================
-- MediTrust - Seed Data for Development & Testing
-- Run AFTER migrations.sql
-- ============================================================

-- ============================================================
-- NOTE: These are sample doctor profiles.
-- Real user auth must be created via Supabase Auth first.
-- These UUIDs are placeholders — replace with real auth user IDs.
-- ============================================================

-- Sample doctors (after creating auth users via Supabase Dashboard or API)
-- INSERT INTO public.profiles (id, first_name, last_name, role, specialization, bio, rating)
-- VALUES
--   ('00000000-0000-0000-0000-000000000001', 'Arjun',   'Sharma',    'doctor', 'Cardiology',       'MBBS, MD - Cardiology. 15 years experience.', 4.9),
--   ('00000000-0000-0000-0000-000000000002', 'Priya',   'Mehta',     'doctor', 'General Medicine',  'MBBS, DNB - General Medicine. 10 years experience.', 4.7),
--   ('00000000-0000-0000-0000-000000000003', 'Rohit',   'Verma',     'doctor', 'Dermatology',       'MBBS, MD - Dermatology. Skin & hair specialist.', 4.8),
--   ('00000000-0000-0000-0000-000000000004', 'Sneha',   'Iyer',      'doctor', 'Pediatrics',        'MBBS, DCH - Pediatrics. Child health specialist.', 4.9),
--   ('00000000-0000-0000-0000-000000000005', 'Karan',   'Kapoor',    'doctor', 'Orthopedics',       'MBBS, MS - Orthopedics. Bone & joint specialist.', 4.6),
--   ('00000000-0000-0000-0000-000000000006', 'Anjali',  'Desai',     'doctor', 'Neurology',         'MBBS, DM - Neurology. Brain & nervous system.', 4.8),
--   ('00000000-0000-0000-0000-000000000007', 'Vikram',  'Nair',      'doctor', 'Psychiatry',        'MBBS, MD - Psychiatry. Mental health specialist.', 4.7),
--   ('00000000-0000-0000-0000-000000000008', 'Pooja',   'Gupta',     'doctor', 'Gynecology',        'MBBS, MS - OBG. Women health specialist.', 4.9);

-- Sample doctor availability (Monday=1 to Sunday=0)
-- INSERT INTO public.doctor_availability (doctor_id, day_of_week, start_time, end_time)
-- VALUES
--   ('00000000-0000-0000-0000-000000000001', 1, '09:00', '17:00'),
--   ('00000000-0000-0000-0000-000000000001', 3, '09:00', '17:00'),
--   ('00000000-0000-0000-0000-000000000001', 5, '09:00', '13:00'),
--   ('00000000-0000-0000-0000-000000000002', 2, '10:00', '18:00'),
--   ('00000000-0000-0000-0000-000000000002', 4, '10:00', '18:00');

-- ============================================================
-- Verify tables exist
-- ============================================================
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;
