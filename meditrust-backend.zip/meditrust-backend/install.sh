#!/bin/bash
# ============================================================
# MediTrust - Setup & Installation Script
# Run: chmod +x install.sh && ./install.sh
# ============================================================

set -e

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   MediTrust - Backend Setup Script       ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── Check Node.js version ──────────────────────────────────
echo "▶ Checking Node.js version..."
NODE_VERSION=$(node -v 2>/dev/null | cut -d'v' -f2 | cut -d'.' -f1)
if [ -z "$NODE_VERSION" ] || [ "$NODE_VERSION" -lt 20 ]; then
  echo "❌ Node.js 20+ is required. Current: $(node -v 2>/dev/null || echo 'not installed')"
  echo "   Install from: https://nodejs.org/"
  exit 1
fi
echo "✅ Node.js $(node -v)"

# ── Check package manager ─────────────────────────────────
echo ""
echo "▶ Checking package manager..."
if command -v pnpm &>/dev/null; then
  PKG_MANAGER="pnpm"
elif command -v npm &>/dev/null; then
  PKG_MANAGER="npm"
else
  echo "❌ npm or pnpm is required."
  exit 1
fi
echo "✅ Using: $PKG_MANAGER"

# ── Copy env file ─────────────────────────────────────────
echo ""
echo "▶ Setting up environment variables..."
if [ ! -f ".env.local" ]; then
  cp .env.example .env.local
  echo "✅ Created .env.local from .env.example"
  echo "⚠️  Please fill in your keys in .env.local before running the app!"
else
  echo "ℹ️  .env.local already exists, skipping."
fi

# ── Install dependencies ──────────────────────────────────
echo ""
echo "▶ Installing Node.js dependencies..."
$PKG_MANAGER install
echo "✅ Node.js packages installed"

# ── Install Python dependencies (optional) ───────────────
echo ""
if command -v pip3 &>/dev/null; then
  echo "▶ Installing Python utilities..."
  pip3 install -r requirements.txt --quiet
  echo "✅ Python packages installed"
else
  echo "ℹ️  Python/pip not found. Skipping Python utilities."
fi

# ── Done ──────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════╗"
echo "║            Setup Complete! ✅             ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo "  1. Fill in your credentials in .env.local"
echo "  2. Run migrations.sql in your Supabase SQL Editor"
echo "  3. Optionally run seed.sql for sample data"
echo "  4. Start the dev server: $PKG_MANAGER dev"
echo ""
