-- ============================================================
-- MediTrust Database Migration Scripts
-- Run these in order in your Supabase SQL Editor
-- ============================================================

-- ============================================================
-- MIGRATION 001: Core Tables
-- ============================================================

-- Profiles table (extends auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
  id              UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  first_name      TEXT,
  last_name       TEXT,
  role            TEXT CHECK (role IN ('patient', 'doctor')) DEFAULT 'patient',
  specialization  TEXT,
  bio             TEXT,
  avatar_url      TEXT,
  rating          NUMERIC(3,2) DEFAULT 5.0,
  total_consultations INTEGER DEFAULT 0,
  is_available    BOOLEAN DEFAULT TRUE,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "profiles_select_own"
  ON public.profiles FOR SELECT USING (auth.uid() = id);

CREATE POLICY "profiles_select_doctors"
  ON public.profiles FOR SELECT USING (role = 'doctor');

CREATE POLICY "profiles_insert_own"
  ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "profiles_update_own"
  ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- ============================================================
-- MIGRATION 002: Consultations
-- ============================================================

CREATE TABLE IF NOT EXISTS public.consultations (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  doctor_id       UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  type            TEXT CHECK (type IN ('ai', 'text', 'video')) DEFAULT 'ai',
  status          TEXT CHECK (status IN ('active', 'completed', 'cancelled')) DEFAULT 'active',
  symptoms        TEXT,
  notes           TEXT,
  total_cost      NUMERIC(10,2) DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  ended_at        TIMESTAMPTZ
);

ALTER TABLE public.consultations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "consultations_select_participants"
  ON public.consultations FOR SELECT USING (
    auth.uid() = patient_id OR auth.uid() = doctor_id
  );

CREATE POLICY "consultations_insert_patient"
  ON public.consultations FOR INSERT WITH CHECK (auth.uid() = patient_id);

CREATE POLICY "consultations_update_participants"
  ON public.consultations FOR UPDATE USING (
    auth.uid() = patient_id OR auth.uid() = doctor_id
  );

-- ============================================================
-- MIGRATION 003: Messages
-- ============================================================

CREATE TABLE IF NOT EXISTS public.messages (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  consultation_id   UUID NOT NULL REFERENCES public.consultations(id) ON DELETE CASCADE,
  sender_id         UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content           TEXT NOT NULL,
  type              TEXT CHECK (type IN ('text', 'audio', 'image')) DEFAULT 'text',
  file_url          TEXT,
  read_at           TIMESTAMPTZ,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "messages_select_participants"
  ON public.messages FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.consultations c
      WHERE c.id = messages.consultation_id
      AND (c.patient_id = auth.uid() OR c.doctor_id = auth.uid())
    )
  );

CREATE POLICY "messages_insert_participant"
  ON public.messages FOR INSERT WITH CHECK (
    auth.uid() = sender_id
    AND EXISTS (
      SELECT 1 FROM public.consultations c
      WHERE c.id = messages.consultation_id
      AND (c.patient_id = auth.uid() OR c.doctor_id = auth.uid())
    )
  );

-- Enable real-time for messages
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;

-- ============================================================
-- MIGRATION 004: Medical Records
-- ============================================================

CREATE TABLE IF NOT EXISTS public.medical_records (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  doctor_id       UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  record_type     TEXT CHECK (record_type IN (
                    'prescription', 'lab_report', 'x_ray',
                    'scan', 'vaccination', 'other'
                  )) DEFAULT 'other',
  file_name       TEXT NOT NULL,
  file_path       TEXT NOT NULL,
  description     TEXT,
  is_shared       BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.medical_records ENABLE ROW LEVEL SECURITY;

CREATE POLICY "medical_records_select_patient"
  ON public.medical_records FOR SELECT USING (
    auth.uid() = patient_id
    OR (is_shared = TRUE AND auth.uid() = doctor_id)
  );

CREATE POLICY "medical_records_insert_patient"
  ON public.medical_records FOR INSERT WITH CHECK (auth.uid() = patient_id);

CREATE POLICY "medical_records_update_patient"
  ON public.medical_records FOR UPDATE USING (auth.uid() = patient_id);

CREATE POLICY "medical_records_delete_patient"
  ON public.medical_records FOR DELETE USING (auth.uid() = patient_id);

-- ============================================================
-- MIGRATION 005: Appointments
-- ============================================================

CREATE TABLE IF NOT EXISTS public.appointments (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id        UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  doctor_id         UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  appointment_date  DATE NOT NULL,
  appointment_time  TIME NOT NULL,
  duration_minutes  INTEGER DEFAULT 30,
  status            TEXT CHECK (status IN (
                      'pending', 'confirmed', 'completed',
                      'cancelled', 'rescheduled'
                    )) DEFAULT 'pending',
  notes             TEXT,
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "appointments_select_own"
  ON public.appointments FOR SELECT USING (
    auth.uid() = patient_id OR auth.uid() = doctor_id
  );

CREATE POLICY "appointments_insert_patient"
  ON public.appointments FOR INSERT WITH CHECK (auth.uid() = patient_id);

CREATE POLICY "appointments_update_participants"
  ON public.appointments FOR UPDATE USING (
    auth.uid() = patient_id OR auth.uid() = doctor_id
  );

-- ============================================================
-- MIGRATION 006: Payments
-- ============================================================

CREATE TABLE IF NOT EXISTS public.payments (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id             UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  order_id            TEXT NOT NULL UNIQUE,
  razorpay_payment_id TEXT,
  amount              NUMERIC(10,2) NOT NULL,
  currency            TEXT DEFAULT 'INR',
  status              TEXT CHECK (status IN (
                        'pending', 'completed', 'failed', 'refunded'
                      )) DEFAULT 'pending',
  consultation_type   TEXT CHECK (consultation_type IN ('ai', 'text', 'video')),
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "payments_select_own"
  ON public.payments FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "payments_insert_own"
  ON public.payments FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "payments_update_own"
  ON public.payments FOR UPDATE USING (auth.uid() = user_id);

-- ============================================================
-- MIGRATION 007: Doctor Availability
-- ============================================================

CREATE TABLE IF NOT EXISTS public.doctor_availability (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id     UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  day_of_week   INTEGER CHECK (day_of_week >= 0 AND day_of_week <= 6),
  start_time    TIME NOT NULL,
  end_time      TIME NOT NULL,
  is_available  BOOLEAN DEFAULT TRUE,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.doctor_availability ENABLE ROW LEVEL SECURITY;

CREATE POLICY "availability_select_all"
  ON public.doctor_availability FOR SELECT USING (TRUE);

CREATE POLICY "availability_insert_own"
  ON public.doctor_availability FOR INSERT WITH CHECK (auth.uid() = doctor_id);

CREATE POLICY "availability_update_own"
  ON public.doctor_availability FOR UPDATE USING (auth.uid() = doctor_id);

CREATE POLICY "availability_delete_own"
  ON public.doctor_availability FOR DELETE USING (auth.uid() = doctor_id);

-- ============================================================
-- MIGRATION 008: Ratings & Reviews
-- ============================================================

CREATE TABLE IF NOT EXISTS public.ratings (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  consultation_id   UUID NOT NULL REFERENCES public.consultations(id) ON DELETE CASCADE,
  patient_id        UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  doctor_id         UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  rating            INTEGER CHECK (rating >= 1 AND rating <= 5) NOT NULL,
  review_text       TEXT,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.ratings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ratings_select_all"
  ON public.ratings FOR SELECT USING (TRUE);

CREATE POLICY "ratings_insert_patient"
  ON public.ratings FOR INSERT WITH CHECK (auth.uid() = patient_id);

-- ============================================================
-- MIGRATION 009: Auto-create Profile Trigger
-- ============================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (
    id,
    first_name,
    last_name,
    role,
    specialization
  )
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'first_name', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'last_name', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'role', 'patient'),
    NEW.raw_user_meta_data ->> 'specialization'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- MIGRATION 010: Update Doctor Rating Function
-- ============================================================

CREATE OR REPLACE FUNCTION public.update_doctor_rating()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.profiles
  SET
    rating = (
      SELECT ROUND(AVG(rating)::NUMERIC, 2)
      FROM public.ratings
      WHERE doctor_id = NEW.doctor_id
    ),
    total_consultations = (
      SELECT COUNT(*)
      FROM public.consultations
      WHERE doctor_id = NEW.doctor_id
      AND status = 'completed'
    )
  WHERE id = NEW.doctor_id;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_new_rating ON public.ratings;

CREATE TRIGGER on_new_rating
  AFTER INSERT ON public.ratings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_doctor_rating();

-- ============================================================
-- MIGRATION 011: Storage Buckets (run via Supabase Dashboard)
-- ============================================================

-- Run these manually in the Supabase Dashboard > Storage section
-- or via the Supabase CLI:
--
-- INSERT INTO storage.buckets (id, name, public)
-- VALUES ('medical-records', 'medical-records', FALSE);
--
-- INSERT INTO storage.buckets (id, name, public)
-- VALUES ('avatars', 'avatars', TRUE);

-- Storage policies for medical-records bucket
CREATE POLICY "medical_records_storage_select"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'medical-records'
    AND auth.uid()::TEXT = (storage.foldername(name))[1]
  );

CREATE POLICY "medical_records_storage_insert"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'medical-records'
    AND auth.uid()::TEXT = (storage.foldername(name))[1]
  );

CREATE POLICY "medical_records_storage_delete"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'medical-records'
    AND auth.uid()::TEXT = (storage.foldername(name))[1]
  );

-- Storage policies for avatars bucket (public)
CREATE POLICY "avatars_storage_select"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'avatars');

CREATE POLICY "avatars_storage_insert"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'avatars'
    AND auth.uid()::TEXT = (storage.foldername(name))[1]
  );

-- ============================================================
-- MIGRATION 012: Indexes for Performance
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_consultations_patient_id
  ON public.consultations(patient_id);

CREATE INDEX IF NOT EXISTS idx_consultations_doctor_id
  ON public.consultations(doctor_id);

CREATE INDEX IF NOT EXISTS idx_consultations_status
  ON public.consultations(status);

CREATE INDEX IF NOT EXISTS idx_messages_consultation_id
  ON public.messages(consultation_id);

CREATE INDEX IF NOT EXISTS idx_messages_created_at
  ON public.messages(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_appointments_patient_id
  ON public.appointments(patient_id);

CREATE INDEX IF NOT EXISTS idx_appointments_doctor_id
  ON public.appointments(doctor_id);

CREATE INDEX IF NOT EXISTS idx_appointments_date
  ON public.appointments(appointment_date);

CREATE INDEX IF NOT EXISTS idx_medical_records_patient_id
  ON public.medical_records(patient_id);

CREATE INDEX IF NOT EXISTS idx_profiles_role
  ON public.profiles(role);

CREATE INDEX IF NOT EXISTS idx_payments_user_id
  ON public.payments(user_id);

CREATE INDEX IF NOT EXISTS idx_payments_order_id
  ON public.payments(order_id);

-- ============================================================
-- DONE — All migrations applied successfully
-- ============================================================
